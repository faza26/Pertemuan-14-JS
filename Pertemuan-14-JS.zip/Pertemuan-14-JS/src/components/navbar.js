import React from "react";

const Navbar = () => {
    return (
        <>
            <div className="navbar">
                <h1>
                    PeTIK Jombang - 2022/2023 
                </h1>
                <img src="https://petik.or.id/wp-content/uploads/2022/08/logo-petik.png"></img>
            </div>
        </>
    )
}


export default Navbar