import React from "react";

const Pesan = () => {
    return (
        <>
        <div className="pesan">
            <h2>Hello world..
                ini adalah Program React JS Pertama Saya
            </h2>
        </div>
        </>
    )
}

export default Pesan;