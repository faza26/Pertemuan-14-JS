import logo from './logo.svg';
import './App.css';
import Navbar from './components/navbar';

function App() {
  return (
    <header className='App-header'>
      <Navbar />
      <pesan/>
      <i> Aufa Zaki</i>
    </header>
  );
}

export default App;
